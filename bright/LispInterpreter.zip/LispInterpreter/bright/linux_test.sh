#!/usr/bin/bash
./bright