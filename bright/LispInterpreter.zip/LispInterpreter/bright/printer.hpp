#pragma once

#include <string>
#include "types.hpp"

std::string pr_str(Value *value);
